﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//based on http://learntocreategames.com/solve_you_linear_algebra_headaches_with_unity

[RequireComponent(typeof(AudioSource))]
public class EnemyFieldOfView : MonoBehaviour
{
    public GameObject m_Player;
    public float m_FieldOfViewAngleDegrees =120;
    public float m_DangerDistance = 5;

    //public GameObject m_LaserBeam;
    public AudioClip m_AlarmSound ;

    public Vector3 m_NormalScale = new Vector3(1,1,1), m_DangerScale = new Vector3 (2,2,2);
    AudioSource m_AlaramAudioSource;
    // Start is called before the first frame update
    void Start()
    {
        m_AlaramAudioSource = GetComponent<AudioSource>();
        //m_LaserBeam.SetActive(false);//disable beam
        InvokeRepeating("DetectPlayer",0,2);
    }

    void DetectPlayer()
    {
        DrawFieldOfView();

        //step 1--get positions    
        Vector3 EnemyPosition = this.transform.position;
        Vector3 PlayerPosition = m_Player.transform.position;

        //step 2-- calculate distance
        float DistanceToPlayer =Vector3.Distance( PlayerPosition , EnemyPosition);
        
        if(DistanceToPlayer<=m_DangerDistance )
           this.transform.localScale = m_DangerScale;
        else
            this.transform.localScale = m_NormalScale;

        //---------------------------------
        //step 3 -- angles
        float AngleRadians = m_FieldOfViewAngleDegrees * Mathf.Deg2Rad;
        float half_absolute_angle = AngleRadians/2;

        //step 4- prepare vectors
        Vector3 EnemyDirection  = this.transform.forward;
        Vector3 PlayerDirection = PlayerPosition - EnemyPosition;
        PlayerDirection.Normalize();

        //step 5 - apply dot product
        float dotProduct = Vector3.Dot(EnemyDirection, PlayerDirection);

        float playerAngle = Mathf.Acos(dotProduct);
        print("player angle ="+playerAngle);


        if(playerAngle<=half_absolute_angle)
        {
            m_AlaramAudioSource.PlayOneShot(m_AlarmSound);
        }
        else 
            m_AlaramAudioSource.Stop();

        /*if(playerAngle<=half_absolute_angle)
        {
            this.transform.LookAt(PlayerPosition);
            m_LaserBeam.SetActive(true);

        }   
        else 
            m_LaserBeam.SetActive(false);
            */

    }
    void DrawFieldOfView()
    {
        //------------------------ Draw view field
        float halfDegrees = m_FieldOfViewAngleDegrees/2;
        Debug.DrawRay(transform.position, Quaternion.Euler (0,halfDegrees,0)*transform.forward*30,Color.green,1);
        Debug.DrawRay(transform.position, Quaternion.Euler (0,-halfDegrees,0)*transform.forward*30,Color.green,1);	

        //We draw a ray for v1 (direction of the NPC) using the same principle
        Debug.DrawRay(transform.position, transform.forward*30, Color.blue,1);

        DrawEllipse(transform.position, transform.forward, transform.up, m_DangerDistance , m_DangerDistance , 32, Color.red,1);
    
    }
     private static void DrawEllipse(Vector3 pos, Vector3 forward, Vector3 up, float radiusX, float radiusY, int segments, Color color, float duration = 0)
    {
        //https://forum.unity.com/threads/solved-debug-drawline-circle-ellipse-and-rotate-locally-with-offset.331397/
        float angle = 0f;
        Quaternion rot = Quaternion.LookRotation(forward, up);
        Vector3 lastPoint = Vector3.zero;
        Vector3 thisPoint = Vector3.zero;
 
        for (int i = 0; i < segments + 1; i++)
        {
            thisPoint.x = Mathf.Sin(Mathf.Deg2Rad * angle) * radiusX;
            thisPoint.y=0;
            thisPoint.z = Mathf.Cos(Mathf.Deg2Rad * angle) * radiusY;
 
            if (i > 0)
            {
                Debug.DrawLine(rot * lastPoint + pos, rot * thisPoint + pos, color, duration);
            }
 
            lastPoint = thisPoint;
            angle += 360f / segments;
        }
    }
    
    // Update is called once per frame
    void Update()
    {
        

    }
}
