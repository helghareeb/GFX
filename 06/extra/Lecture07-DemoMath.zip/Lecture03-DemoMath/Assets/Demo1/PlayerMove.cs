﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//based on http://learntocreategames.com/solve_you_linear_algebra_headaches_with_unity
public class PlayerMove : MonoBehaviour
{
    public float m_Speed =3;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        float h = Input.GetAxis("Horizontal");
        float v= Input.GetAxis("Vertical");
        Vector3 direction = new Vector3(h,0,v);

        this.transform.Translate (direction*m_Speed *Time.deltaTime);
    }
}
